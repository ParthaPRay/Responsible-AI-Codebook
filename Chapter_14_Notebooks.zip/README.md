# Responsible AI — Chapter 14 Practical Notebooks

**Chapter:** Responsible Generative AI, Foundation Models and Agentic AI
**Creator:** Partha Pratim Ray

Each notebook contains exactly two cells: one Markdown instructional cell followed by one Python code cell.
Requires commonly available Python packages: numpy, pandas, matplotlib, scikit-learn. All experiments work offline and require no API keys.

## Contents

1. `ch14_01_Discriminative_vs_Generative_Digits.ipynb` — Discriminative and Generative Modelling on Handwritten Digits
2. `ch14_02_Next_Token_Sampling.ipynb` — Autoregressive Next-Token Generation and Sampling
3. `ch14_03_Attention_And_Context.ipynb` — Scaled Dot-Product Attention and Context Sensitivity
4. `ch14_04_Generative_Fidelity_Privacy.ipynb` — Synthetic Data Fidelity, Utility and Memorisation Checks
5. `ch14_05_Grounding_And_Citation_Verification.ipynb` — Retrieval Grounding, Source Support and Abstention
6. `ch14_06_Hallucination_Claim_Audit.ipynb` — Claim-Level Verification and Hallucination Audit
7. `ch14_07_Agent_Permissions_And_Human_Gates.ipynb` — Agentic Tool Permissions, Human Approval and Audit Trails
8. `ch14_08_Memory_Provenance_And_Retention.ipynb` — Persistent Agent Memory, Provenance and Retention
9. `ch14_09_Multi_Agent_Cascade_And_Budgets.ipynb` — Multi-Agent Delegation, Verification and Cascading Failures
10. `ch14_10_Integrated_Responsibility_Audit.ipynb` — Generative and Agentic AI Responsibility Audit

## Notes
- Synthetic and controlled examples are not evidence of real model compliance, security, privacy, or safety.
- Saved plots use 600 DPI.
- The instructor should discuss source authority, limitations, affected people and human oversight.
