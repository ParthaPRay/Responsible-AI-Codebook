# Chapter 12 — AI Risk Management, Impact Assessment and Assurance

Creator: Partha Pratim Ray

Each notebook uses exactly two cells (Markdown introduction + single executable Python cell).
All scenarios not based on public datasets are explicitly hypothetical. Risk indices are not measures of actual expected harm.
Standard libraries: NumPy, Pandas, Matplotlib, SciPy, Scikit-learn where relevant.
Plots are saved at 600 DPI upon execution.

## Contents

- `ch12_01_risk_exposure.ipynb` — Risk, Likelihood, Severity and Exposure
- `ch12_02_risk_matrix.ipynb` — Risk Matrix and Sensitivity Analysis
- `ch12_03_risk_register.ipynb` — Operational Risk Register and Control Matrix
- `ch12_04_bias_impact.ipynb` — Algorithmic Impact Assessment: Subgroup Evidence
- `ch12_05_controls.ipynb` — Control Effectiveness and Residual-Risk Sensitivity
- `ch12_06_assurance.ipynb` — Assurance Claims, Evidence and Verification
- `ch12_07_monitoring.ipynb` — Key Risk Indicators and Monitoring Triggers
- `ch12_08_framework_mapping.ipynb` — AI Risk Framework Mapping and Coverage Gaps
- `ch12_09_environment.ipynb` — Environmental Impact: Energy, Carbon and Workload
- `ch12_10_stakeholder.ipynb` — Impact Assessment: Stakeholder and Rights Coverage
- `ch12_11_assurance_release.ipynb` — Integrated Risk and Assurance Release Gate
