# Chapter 7 — Transparency, Interpretability and Explainable AI

Companion labs for **Responsible AI**, by **Partha Pratim Ray**.

Every `.ipynb` has exactly **two cells**: (1) a Markdown introduction with objectives and student exercise; (2) one complete, runnable Python cell.
The notebooks require no API keys, network access, paid packages or external dataset downloads. They use commonly available Colab libraries and write figures into `chapter7_outputs/` at **600 DPI**.

## Lab index

- **ch7_01_linear_logistic.ipynb** — Linear and Logistic Models: Exact Contributions. Calculate exact additive contributions for a linear model and log-odds contributions for a logistic model.
- **ch7_02_tree_rules.ipynb** — Decision Trees and Ordered Rules. Trace small decision paths and compare them with first-match rule-list semantics.
- **ch7_03_permutation_importance.ipynb** — Global Permutation Importance. Compute held-out permutation importance for a model and explore correlated-feature limitations.
- **ch7_04_pdp_ale.ipynb** — Partial Dependence and Accumulated Local Effects. Calculate both PDP and 1-D ALE for a correlated synthetic feature pair to reveal interpretation differences.
- **ch7_05_lime_local.ipynb** — LIME-Style Local Surrogate. Fit a kernel-weighted linear surrogate around a fixed nonlinear prediction and measure its local fidelity.
- **ch7_06_shapley_exact.ipynb** — Exact Shapley Attribution for a Two-Feature Model. Calculate two-feature Shapley contributions by enumerating coalitions relative to an explicit baseline.
- **ch7_07_counterfactual.ipynb** — Counterfactual Explanations and Feasible Recourse. Distinguish a nearest model-flipping change from an actionable, constraint-respecting recourse.
- **ch7_08_examples_prototypes.ipynb** — Example-Based Explanations and Similarity. Compare nearest examples under scaled and unscaled Euclidean distance, and identify sensitivity to feature units.
- **ch7_09_global_surrogate.ipynb** — Global Surrogate Fidelity and Complexity. Approximate a nonlinear black-box model with decision trees of varying depth and quantify fidelity on held-out inputs.
- **ch7_10_modality_explanations.ipynb** — Saliency and Temporal Perturbation Explanations. Demonstrate input-perturbation sensitivity on a digit classifier and a toy temporal predictor.
- **ch7_11_explanation_audit.ipynb** — Explanation Quality, Stability and Contestability Audit. Compare explanation repeatability, local fidelity, stakeholder usefulness, and decision-log completeness as separate evidence dimensions.

## Important caveats

The synthetic and pedagogical models are not operational scoring policies or validated decision aids. Post-hoc attributions and perturbation effects describe model behaviour, not automatically causes. Explanation quality, performance, fairness, safety, and accountability must be assessed separately.

## Usage

Upload any notebook to Google Colab and choose Runtime → Run all. The PNG output is saved in the session folder `chapter7_outputs/`.
