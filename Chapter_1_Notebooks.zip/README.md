# Chapter 1 — Artificial Intelligence as a Socio-Technical System

Created by **Partha Pratim Ray** for classroom exercises accompanying *Responsible AI*.

Each `.ipynb` has exactly **two cells**: an instructional Markdown cell and one standalone Python cell. The notebooks run in Google Colab without API keys or external downloads.

Charts save at **600 DPI** to the current directory. Some labs generate CSV records. All scenarios are educational and do not constitute clinical, legal or safety validation.

## Experiments

- `ch1_01_symbolic_statistical_hybrid.ipynb` — Symbolic, Statistical and Hybrid AI.
- `ch1_02_learning_generalisation.ipynb` — Learning, Generalisation and Overfitting.
- `ch1_03_class_imbalance.ipynb` — Why Accuracy Alone Is Insufficient.
- `ch1_04_group_representation.ipynb` — Group Representation and Unequal Errors.
- `ch1_05_threshold_values.ipynb` — Decision Thresholds Encode Value Choices.
- `ch1_06_human_oversight.ipynb` — From Predictive AI to Human Review.
- `ch1_07_feedback_loops.ipynb` — Socio-Technical Feedback Loops.
- `ch1_08_data_leakage.ipynb` — Lifecycle Data Preparation and Leakage.
- `ch1_09_lifecycle_governance.ipynb` — AI Lifecycle Gates and Evidence.
- `ch1_10_integrated_readiness.ipynb` — Integrated Socio-Technical Deployment Review.
