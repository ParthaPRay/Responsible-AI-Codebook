# Chapter 15 — International AI Governance: Political Economy, Geopolitics and Public Narratives

Creator: Partha Pratim Ray

Two-cell Google Colab teaching laboratories. Each notebook has one Markdown cell and one self-contained Python code cell.

All datasets, scores, supplier structures, and payoffs are fictional classroom exercises; no lab certifies a real-world legal or geopolitical conclusion.

Packages: numpy, pandas, matplotlib (standard Colab packages). No paid APIs, internet, or model downloads. Figures are saved at 600 DPI in notebook-specific output folders.

## Notebook list

- `ch15_01_distributional_benefits_burdens.ipynb` — Stakeholder Distribution of Benefits and Burdens
- `ch15_02_supplier_concentration_hhi.ipynb` — Supplier Concentration and Shared Upstream Dependencies
- `ch15_03_cloud_access_capacity.ipynb` — Nominal versus Usable AI Compute Capacity
- `ch15_04_lifecycle_cost_migration.ipynb` — Three-Year Procurement, Switching and Migration Costs
- `ch15_05_dependency_recovery_horizons.ipynb` — Time-Indexed Dependency and Bottleneck Indicators
- `ch15_06_cross_border_service_mapping.ipynb` — Cross-Border Data Flows, Control Rights and Evidence Gaps
- `ch15_07_consultation_representation.ipynb` — Consultation Representation and Substantive Influence
- `ch15_08_public_claim_evidence.ipynb` — Public-Narrative Claims and Evidence Audits
- `ch15_09_cooperation_game.ipynb` — Geopolitical Cooperation and Repeated Incentives
- `ch15_10_policy_multi_criteria.ipynb` — Cross-Border Procurement: Constraints, Sensitivity and Policy Choice
- `ch15_11_sovereignty_control_test.ipynb` — Operational Sovereignty: Formal Rights versus Tested Capacity
