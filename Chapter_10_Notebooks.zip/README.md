# Responsible AI — Chapter 10: AI Safety, Human Oversight and Control

Creator: Partha Pratim Ray

Each notebook has exactly two cells: (1) Markdown introduction and exercise; (2) complete self-contained Python experiment.

All experiments are educational, using public benchmark or explicitly simulated data. They do not establish real-world safety certification.

## Notebook inventory

- `ch10_01_goal_misspecification.ipynb` — Goal Misspecification and Proxy-Reward Gaming
- `ch10_02_human_oversight.ipynb` — Human-in-the-Loop and Automation Bias
- `ch10_03_intervention_timing.ipynb` — Human Intervention Time and Emergency Shutdown
- `ch10_04_fault_tree.ipynb` — Fault-Tree Analysis and Common-Cause Failures
- `ch10_05_fmea.ipynb` — Failure Modes and Effects Analysis (FMEA)
- `ch10_06_safety_constraints.ipynb` — Agent Safety Constraints and Budget Enforcement
- `ch10_07_operational_boundaries.ipynb` — Operational Design Domain and Safe Fallback
- `ch10_08_safety_evaluation.ipynb` — Safety Evaluation, Capability and Failure Rates
- `ch10_09_acceptance_bounds.ipynb` — Pre-Deployment Safety Acceptance Using Confidence Bounds
- `ch10_10_monitoring_case_mix.ipynb` — Post-Deployment Monitoring and Case-Mix Standardisation
- `ch10_11_incident_response.ipynb` — Incident Response, Containment and Recovery Verification
