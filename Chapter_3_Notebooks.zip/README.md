# Chapter 3 — Human Values, Power and Responsible Design

Creator: Partha Pratim Ray

Ten standalone two-cell Google Colab notebooks. Each has one Markdown cell and one Python code cell. Dependencies: NumPy, Pandas, Matplotlib, scikit-learn (standard Colab packages). Figures are exported as 600-DPI PNGs.

All demonstrations are educational; synthetic scenarios are explicitly labelled and do not constitute factual findings about real populations.

## Notebooks

- `ch3_01_values_in_objective_functions.ipynb` — Values Embedded in Objective Functions
- `ch3_02_representation_and_labels.ipynb` — Dataset Representation and Classification Power
- `ch3_03_stakeholder_power_map.ipynb` — Stakeholder Influence, Impact and Representation
- `ch3_04_benefits_burdens.ipynb` — Distribution of Benefits and Burdens
- `ch3_05_agency_automation_bias.ipynb` — Human Agency and Automation Bias
- `ch3_06_dark_patterns_choice.ipynb` — Informed Choice and Dark-Pattern Scenarios
- `ch3_07_accessibility_and_inclusion.ipynb` — Inclusive and Accessible AI Service Evaluation
- `ch3_08_participatory_codesign.ipynb` — Participatory Design and Stakeholder Feedback
- `ch3_09_value_sensitive_design.ipynb` — Value-Sensitive Design Trade-Off Workshop
- `ch3_10_stakeholder_design_audit.ipynb` — Chapter Laboratory: Stakeholder, Power and Value-Impact Audit
