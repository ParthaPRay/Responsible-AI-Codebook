# Chapter 9 — AI Security, Robustness and Reliability

**Creator:** Partha Pratim Ray

Eleven two-cell Colab-ready notebooks. Each contains one Markdown cell and one self-contained code cell. Python code uses NumPy, Pandas, Matplotlib and scikit-learn; demonstrations use public sklearn datasets or explicitly stated simulations.

All notebook figures are exported as 600 DPI PNG files when run.

| Notebook | Experiment |
|---|---|
| `ch9_01_Digits_Noise_Robustness.ipynb` | Image Noise and Model Robustness |
| `ch9_02_Label_Poisoning.ipynb` | Training-Label Poisoning and Performance |
| `ch9_03_Triggered_Backdoor_Simulation.ipynb` | Trigger-Dependent Misclassification Simulation |
| `ch9_04_Black_Box_Model_Extraction.ipynb` | Black-Box Model Behaviour Approximation |
| `ch9_05_Prompt_Injection_Trust_Boundaries.ipynb` | Indirect Prompt Injection and Tool Authorization |
| `ch9_06_Domain_Shift.ipynb` | Domain Shift and Importance-Weighted Error |
| `ch9_07_OOD_Detection.ipynb` | Out-of-Distribution Detection with Mahalanobis Distance |
| `ch9_08_Probability_Calibration.ipynb` | Predictive Probability Calibration and Brier Score |
| `ch9_09_Selective_Prediction.ipynb` | Selective Prediction: Coverage and Abstention |
| `ch9_10_Conformal_Prediction.ipynb` | Split Conformal Prediction Sets |
| `ch9_11_Reliability_and_Fallback.ipynb` | Service Reliability, Timeouts, and Graceful Degradation |
