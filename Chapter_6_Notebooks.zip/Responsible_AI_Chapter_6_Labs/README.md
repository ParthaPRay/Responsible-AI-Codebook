# Responsible AI — Chapter 6: Fairness in Machine Learning

Author / creator: **Partha Pratim Ray**

Eleven independent Google Colab-compatible laboratory notebooks, exactly two cells each (Markdown instructions + one executable Python cell).

## Notebook index

- `ch6_01_01_equality_equity.ipynb` — Equality, Equity, Procedural and Group Fairness
- `ch6_02_02_group_performance.ipynb` — Group Confusion Matrices and Predictive Performance
- `ch6_03_03_group_fairness.ipynb` — Demographic Parity, Equal Opportunity, Equalised Odds and Disparate Impact
- `ch6_04_04_calibration.ipynb` — Calibration Within Groups and Probability Reliability
- `ch6_05_05_uncertainty.ipynb` — Fairness Estimates and Wilson Confidence Intervals
- `ch6_06_06_intersectional.ipynb` — Intersectional Fairness and Small-Cell Suppression
- `ch6_07_07_individual_counterfactual.ipynb` — Individual Similarity and Counterfactual Sensitivity
- `ch6_08_08_impossibility.ipynb` — Fairness Trade-offs with Unequal Base Rates
- `ch6_09_09_preprocessing.ipynb` — Pre-processing Mitigation through Group Reweighting
- `ch6_10_10_postprocessing.ipynb` — Post-processing Group Thresholds with Separate Validation
- `ch6_11_11_integrated_audit.ipynb` — Integrated Fairness Audit and Monitoring Register

## Run
Upload any `.ipynb` to Colab and choose **Runtime → Run all**. Each notebook runs without external datasets, paid APIs or downloads. Plots are saved locally to `ch6_outputs/` at 600 DPI.

## Boundaries
The data and labels are illustrative. Equality of one statistical metric is not sufficient evidence of ethical fairness. For real deployment assess label validity, uncertainty, local requirements, affected groups and appeal mechanisms.
