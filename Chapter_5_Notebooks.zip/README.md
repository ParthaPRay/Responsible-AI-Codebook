# Chapter 5 — Bias and Harm: Colab Laboratory Notebooks

Creator: **Partha Pratim Ray**

Each notebook has exactly **two cells**: an instructional Markdown cell and an independently runnable Python cell. Requires NumPy, Pandas, Matplotlib and Scikit-learn (available in Google Colab). No external data, credentials, APIs or model downloads. Each notebook saves a **600-DPI PNG** in the working directory.

## Experiments

1. `ch5_01_statistical_bias.ipynb` — Statistical Estimator Bias Versus Social Discrimination
2. `ch5_02_sampling_representation.ipynb` — Sampling and Representation Bias
3. `ch5_03_measurement_label.ipynb` — Measurement and Labelling Bias
4. `ch5_04_historical_proxy.ipynb` — Historical Bias and Proxy Variables
5. `ch5_05_selection_error.ipynb` — Selection Rates and Error Disparities
6. `ch5_06_intersectionality.ipynb` — Intersectional Group Evaluation
7. `ch5_07_aggregation_learning.ipynb` — Aggregation and Learning Bias
8. `ch5_08_feedback_language.ipynb` — Exposure-Driven Recommendation Feedback
9. `ch5_09_harms_taxonomy.ipynb` — Allocative, Representational and Service-Quality Harms
10. `ch5_10_bounded_harm.ipynb` — Expected Affected Counts and Bounded Harm
11. `ch5_11_integrated_audit.ipynb` — Integrated Bias, Harm, and Remedy Audit

All examples are fictional or simulation-based. Differences in statistical rates do not, without context, establish discrimination, causation, or the severity of harms. The final notebook saves an illustrative CSV audit register.
