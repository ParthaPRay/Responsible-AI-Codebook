# Chapter 13 — Global AI Governance and Law

Author/Creator: Partha Pratim Ray

Ten self-contained Google Colab/Jupyter notebooks. Each contains **exactly two cells** (Markdown followed by Python). All regulatory examples are classroom illustrations rather than legal advice or definitive current-law mappings. Legal status, jurisdiction, scope and effective date must be verified before any real deployment.

## Notebooks

- `ch13_01_Governance_Models_Matrix.ipynb` — Governance Models: Comparative Decision Matrix
- `ch13_02_Risk_Based_Controls.ipynb` — Risk-Based Governance and Proportionate Controls
- `ch13_03_International_Instruments.ipynb` — International Instruments: Status and Coverage
- `ch13_04_India_Governance_Layers.ipynb` — India: Distributed Governance Responsibilities
- `ch13_05_Obligation_Traceability.ipynb` — Legal-Obligation Traceability and Evidence Gaps
- `ch13_06_Synthetic_Content_Provenance.ipynb` — Synthetic Content: Labelling and Provenance Tests
- `ch13_07_Value_Chain_RACI.ipynb` — Foundation Model Value Chain: Responsibility and RACI
- `ch13_08_Cross_Border_Data_Flows.ipynb` — Cross-Border AI: Data Flow and Governance Checklist
- `ch13_09_Regulatory_Change_Control.ipynb` — Regulatory Change Management and Reassessment
- `ch13_10_Governance_Audit_Summary.ipynb` — Integrated Governance Audit: Controls, Evidence and Remedy

## Run
Open any `.ipynb` in Google Colab or Jupyter and run the second cell. Requires numpy, pandas, matplotlib, scikit-learn and IPython.

## Boundaries
The governance and compliance examples contain fictional ratings, workflows and evidence. A table flag or control score does not prove legal compliance. Verify actual rules, jurisdiction, applicability and enforcement dates from authoritative publications.