# Chapter 11 — Accountability, Documentation and AI Auditing

**Creator:** Partha Pratim Ray

Each Google Colab-compatible Jupyter notebook contains exactly two cells: a Markdown introduction and one executable Python cell. Experiments use built-in datasets or explicitly fictional/simulated records. Graphs export at 600 DPI. No credentials required.

## Notebooks

- `ch11_01_responsibility_raci.ipynb` — Responsibility Mapping and RACI Gaps
- `ch11_02_evidence_completeness.ipynb` — Audit Evidence Completeness and Missing Evidence
- `ch11_03_traceability_weighted.ipynb` — Decision Traceability and Consequence-Weighted Coverage
- `ch11_04_model_card.ipynb` — Model Card with Reproducible Subgroup Metrics
- `ch11_05_audit_trail.ipynb` — Audit Trail, Decision Reconstruction and Version Lineage
- `ch11_06_technical_audit.ipynb` — Technical AI Audit: Accuracy, Group Error and Evidence
- `ch11_07_audit_sampling.ipynb` — Audit Sampling and Rare-Issue Detection
- `ch11_08_contestability.ipynb` — Contestability, Human Review and Remedy Metrics
- `ch11_09_remediation.ipynb` — Audit Findings, Corrective Actions and Verified Closure
- `ch11_10_audit_checklist.ipynb` — AI Audit Checklist and Evidence-Gap Register
- `ch11_11_change_control.ipynb` — Model Version Changes and Audit Revalidation

## Usage
Open any `.ipynb` file in Google Colab and run the second cell. Generated PNG, JSON or CSV files appear in the runtime working directory.

## Educational cautions
Technical audit metrics need defined criteria, appropriate reference populations, independent verification, and contextual review. A generated model card or recorded evidence does not constitute approval or certification.