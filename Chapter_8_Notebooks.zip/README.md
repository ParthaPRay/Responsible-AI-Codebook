# Chapter 8: Privacy and Privacy-Preserving AI

Creator: Partha Pratim Ray

Each Jupyter notebook has exactly two cells: one Markdown learning cell and one complete code cell. Run on Google Colab or locally with NumPy, Pandas, Matplotlib, SciPy and Scikit-learn. All example data are public or fabricated. Figures are exported at 600 DPI.

## Laboratories

1. `ch8_01_reidentification_linkage.ipynb` — Re-identification and Quasi-Identifier Linkage
2. `ch8_02_membership_inference_metrics.ipynb` — Membership Inference: Confusion Matrix and Prevalence
3. `ch8_03_attribute_inference_uplift.ipynb` — Attribute Inference: Auxiliary Baseline and Model-Access Uplift
4. `ch8_04_data_minimisation.ipynb` — Data Minimisation and Predictive Utility
5. `ch8_05_k_anonymity_aggregation.ipynb` — k-Anonymity, Equivalence Classes and Aggregate Differencing
6. `ch8_06_differential_privacy_laplace.ipynb` — Differential Privacy: Laplace Noise and Utility
7. `ch8_07_privacy_composition.ipynb` — Differential Privacy Composition and Release Budget
8. `ch8_08_federated_learning_simulation.ipynb` — Federated Learning: FedAvg on Partitioned Data
9. `ch8_09_synthetic_data_audit.ipynb` — Synthetic Data: Fidelity, Utility, and Nearest-Neighbour Audits
10. `ch8_10_agentic_privacy_permissions.ipynb` — Agentic AI: Retrieval Permissions and Data-Loss Prevention

## Caveats
These notebooks are teaching demonstrations. Differential privacy bounds depend on defined adjacency and actual mechanisms; federated learning does not by itself guarantee privacy; k-anonymity does not prove anonymity; model-access testing is not a substitute for application access controls.
