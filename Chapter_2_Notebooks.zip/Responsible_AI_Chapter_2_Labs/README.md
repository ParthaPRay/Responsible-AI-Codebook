# Chapter 2 — Ethics, Human Rights and Moral Reasoning

Two-cell Google Colab laboratory notebooks
Creator: Partha Pratim Ray

Each notebook contains one Markdown instruction cell and one executable Python cell.
Requirements: numpy, pandas, matplotlib (standard Colab packages).
No internet access, API credentials or personal data required.
All example stakeholders, scores and outcomes are fictional; never use the results as legal or ethical certification.

## Experiments

1. `ch2_01_facts_assumptions_value_judgements.ipynb` — Facts, Assumptions and Value Judgements
2. `ch2_02_ethical_theories_tradeoffs.ipynb` — Comparing Ethical Theories on Alternative AI Designs
3. `ch2_03_distributional_justice.ipynb` — Distributional Justice: Equality, Equity and Need
4. `ch2_04_intersectional_errors.ipynb` — Intersectional Error Analysis and Evidence Limits
5. `ch2_05_privacy_utility_frontier.ipynb` — Privacy–Utility Choices and Ethical Constraints
6. `ch2_06_human_rights_remedy.ipynb` — Human Rights, Appeals and Access to Remedy
7. `ch2_07_stakeholder_map.ipynb` — Stakeholder Mapping, Power and Unheard Voices
8. `ch2_08_ethics_of_care_capabilities.ipynb` — Ethics of Care and Real Capabilities
9. `ch2_09_disagreement_sensitivity.ipynb` — Ethical Disagreement and Sensitivity Analysis
10. `ch2_10_documented_ethical_assessment.ipynb` — Integrated Ethical Assessment and Evidence Register
