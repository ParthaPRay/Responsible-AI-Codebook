# Chapter 4 — Responsible Data and Dataset Governance

**Creator:** Partha Pratim Ray

This collection consists of 11 independent, two-cell Google Colab notebooks supporting the Responsible AI textbook. Each notebook has one Markdown cell (objectives, method, student activities, cautions) and one executable Python cell. All experiments use built-in sklearn datasets or synthetic data and require no API keys or downloads. Each exports a 600-DPI PNG figure to the working directory. Some produce CSV and JSON governance records.

## Notebook index

- `ch4_01_data_types_and_quality.ipynb` — Data Types, Quality Rules, and Fitness for Purpose
- `ch4_02_train_validation_test.ipynb` — Train, Validation, Test and Pipeline Boundaries
- `ch4_03_population_sampling.ipynb` — Population, Sampling Frames, and Representativeness
- `ch4_04_missingness.ipynb` — MCAR, MAR, MNAR and Imputation Sensitivity
- `ch4_05_class_imbalance.ipynb` — Class Imbalance, Accuracy and Minority Recall
- `ch4_06_entity_and_target_leakage.ipynb` — Target Leakage and Entity Overlap
- `ch4_07_correlation_confounding.ipynb` — Correlation, Confounding and Causal Interpretation
- `ch4_08_distribution_concept_shift.ipynb` — Distribution Shift versus Concept Shift
- `ch4_09_quantitative_audit.ipynb` — Quantitative Dataset Audit and Complete-Record Bounds
- `ch4_10_annotation_agreement.ipynb` — Annotation Quality, Ambiguity and Disagreement
- `ch4_11_documentation_governance.ipynb` — Dataset Documentation, Lineage, Access and Retention Audit

## Running

Open any `.ipynb` file in Google Colab or Jupyter, then execute the second cell. Packages: `numpy`, `pandas`, `matplotlib`, `scikit-learn`. The quantitative cases are illustrative and do not confer ethical or legal certification.
